import type {ComponentProps} from 'react'
import {Brand} from './Brand.tsx'
import {LoginView} from './Login.tsx'

/** Shared visual shell; authentication remains owned by LoginView. */
export function AdminLogin(props: ComponentProps<typeof LoginView>) {
  return <div className="admin-auth"><aside className="admin-auth-story"><Brand subtitle="企业工作平台"/><div><p className="admin-auth-kicker">LETS ENTERPRISE</p><h2>企业资源，<br/>统一管理。</h2><p>管理成员与权限，配置企业资源，<br/>查看业务用量。</p><div className="admin-auth-capabilities"><span>组织与权限</span><span>模型与资源</span><span>运营分析</span></div></div><footer>LETS · 企业管理工作台</footer></aside><div className="admin-auth-form"><LoginView {...props}/></div></div>
}
