import { useId, useRef, useState, type FormEvent } from 'react'
import {Brand,Icon} from './Brand.tsx'
export interface LoginViewProps {
  login:(username:string,password:string,remember:boolean)=>Promise<void>;
  changePassword?:(currentPassword:string,password:string)=>Promise<void>;
  mustChangePassword?:boolean; allowRemember?:boolean; message?:string; title?:string;
  serviceOrigin?:string; changeService?:()=>Promise<void>;
}
/** Shared by the sandboxed Electron login page and the browser development preview. */
export function LoginView({login,changePassword,mustChangePassword=false,allowRemember=false,message,title='登录企业工作区',serviceOrigin,changeService}:LoginViewProps){
  const [username,setUsername]=useState(''),[password,setPassword]=useState(''),[next,setNext]=useState(''),[confirm,setConfirm]=useState('')
  const [remember,setRemember]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('')
  const errorRef=useRef<HTMLParagraphElement>(null)
  async function submit(event:FormEvent){
    event.preventDefault();setError('')
    if(mustChangePassword && next!==confirm){setError('两次输入的新密码不一致');requestAnimationFrame(()=>errorRef.current?.focus());return}
    setBusy(true)
    try{
      if(mustChangePassword){if(!changePassword)throw new Error('当前无法修改密码');await changePassword(password,next)}
      else await login(username,password,remember)
      setPassword('');setNext('');setConfirm('')
    }catch(e){setError(e instanceof Error?e.message:'登录失败，请重试');requestAnimationFrame(()=>errorRef.current?.focus())}
    finally{setBusy(false)}
  }
  return <main className="login-shell"><section className="login-card" aria-label="企业账号登录">
    <div className="login-brand-band"><Brand subtitle="企业工作平台"/></div>
    <div className="login-body"><p className="eyebrow">ENTERPRISE WORKSPACE</p>
    <h1>{mustChangePassword?'设置你的新密码':title}</h1>
    <p className="muted">{mustChangePassword?'首次登录或管理员重置后，需要修改临时密码。':'使用管理员分配的账号，进入你的专属工作区。'}</p>
    {serviceOrigin&&<div className="login-service"><div><span>当前企业服务</span><strong title={serviceOrigin}>{serviceOrigin}</strong></div>{changeService&&<button type="button" disabled={busy} onClick={()=>{setBusy(true);setError('');void changeService().catch((e:unknown)=>{setError(e instanceof Error?e.message:'无法更换服务，请重试');requestAnimationFrame(()=>errorRef.current?.focus())}).finally(()=>setBusy(false))}}>更换</button>}</div>}
    {message&&<p className="notice" role="status">{message}</p>}
    <form onSubmit={e=>void submit(e)}>
      {!mustChangePassword&&<label>账号<div className="login-input"><Icon name="account" size={17}/><input autoFocus autoComplete="username" placeholder="输入企业账号" value={username} disabled={busy} onChange={e=>setUsername(e.target.value)} required maxLength={64}/></div></label>}
      <PasswordField label={mustChangePassword?'当前／临时密码':'密码'} value={password} onChange={setPassword} disabled={busy}/>
      {mustChangePassword&&<><PasswordField label="新密码" value={next} onChange={setNext} disabled={busy} newPassword/><small className="password-hint">至少 12 个字符，支持粘贴和密码管理器。</small><PasswordField label="确认新密码" value={confirm} onChange={setConfirm} disabled={busy} newPassword/></>}
      {!mustChangePassword&&allowRemember&&<label className="check"><input type="checkbox" checked={remember} onChange={e=>setRemember(e.target.checked)}/>记住登录，最长 7 天</label>}
      {error&&<p ref={errorRef} tabIndex={-1} className="error" role="alert">{error}</p>}
      <button className="primary full" disabled={busy}>{busy?'正在验证…':mustChangePassword?'修改密码并继续':'登录'}{!busy&&<Icon name="arrow" size={17}/>}</button>
    </form><p className="login-foot">忘记密码？请联系企业管理员重置。</p>
    </div><footer className="login-security"><Icon name="shield" size={14}/>企业身份验证 · 按账号隔离数据</footer>
  </section></main>
}

function PasswordField({label,value,onChange,disabled,newPassword=false}:{label:string;value:string;onChange:(value:string)=>void;disabled:boolean;newPassword?:boolean}){
  const [visible,setVisible]=useState(false),id=useId()
  return <div className="password-field"><label htmlFor={id}>{label}</label><div className="login-input"><Icon name="lock" size={17}/><input id={id} type={visible?'text':'password'} autoComplete={newPassword?'new-password':'current-password'} placeholder={newPassword?'至少 12 个字符':'输入密码'} value={value} onChange={e=>onChange(e.target.value)} required minLength={newPassword?12:undefined} maxLength={128} disabled={disabled}/><button type="button" aria-label={`${visible?'隐藏':'显示'}${label}`} aria-pressed={visible} onClick={()=>setVisible(previous=>!previous)}><Icon name="eye" size={17}/></button></div></div>
}
