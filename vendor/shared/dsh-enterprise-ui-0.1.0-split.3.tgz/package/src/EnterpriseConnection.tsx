import {useEffect,useRef,useState,type FormEvent} from 'react'
import {Brand,Icon} from './Brand.tsx'

export interface EnterpriseConnectionProps {
  origin:string; message:string
  addressHint?:string
  instanceChange?:{previous:string;next:string}
  connect:(origin:string)=>Promise<void>
  confirm:()=>Promise<void>
  cancel:()=>Promise<void>
}
/** Only address selection lives in the renderer; all requests/pins belong to main. */
export function EnterpriseConnection({origin,message,addressHint='优先填写 HTTPS 根地址，不需要 /api/v1；内网 HTTP 需由管理员明确启用兼容。',instanceChange,connect,confirm,cancel}:EnterpriseConnectionProps){
  const [value,setValue]=useState(origin),[busy,setBusy]=useState(false),[error,setError]=useState('')
  const errorRef=useRef<HTMLParagraphElement>(null)
  useEffect(()=>{setValue(origin)},[origin])
  async function run(work:()=>Promise<void>){
    setBusy(true);setError('')
    try{await work()}catch(e){setError(e instanceof Error?e.message:'连接失败，请检查地址后重试。');requestAnimationFrame(()=>errorRef.current?.focus())}finally{setBusy(false)}
  }
  function submit(e:FormEvent){e.preventDefault();void run(()=>instanceChange?confirm():connect(value))}
  return <main className="login-shell enterprise-connection"><section className="login-card" aria-label="连接企业服务">
    <div className="login-brand-band"><Brand subtitle="企业工作平台"/></div>
    <div className="login-body"><p className="eyebrow">CONNECT YOUR ENTERPRISE</p>
      <h1>{instanceChange?'确认企业服务变更':'连接企业服务'}</h1>
      <p className="muted">{instanceChange?'同一地址的企业身份与上次不同。请先联系管理员确认，再使用新企业账号登录。':'填写管理员提供的地址，连接后使用企业账号登录。地址会保存在本机，下次自动连接。'}</p>
      {message&&<p className="notice" role="status">{message}</p>}
      <form onSubmit={submit} aria-busy={busy}>
        <label htmlFor="enterprise-service-origin">企业服务地址</label>
        <div className="login-input"><Icon name="globe" size={17}/><input id="enterprise-service-origin" type="url" autoFocus autoComplete="off" autoCapitalize="none" spellCheck={false} placeholder="https://ai.your-company.cn" value={value} onChange={e=>setValue(e.target.value)} disabled={busy||Boolean(instanceChange)} required maxLength={2000} aria-describedby="enterprise-service-hint"/></div>
        <small id="enterprise-service-hint" className="connection-hint">{addressHint}</small>
        {instanceChange&&<div className="login-service-change" role="alert"><strong>不会自动恢复旧企业凭证</strong><p>聊天记录和工作区将继续按企业身份隔离，不会删除原有数据。</p><dl><dt>原企业标识</dt><dd>{instanceChange.previous}</dd><dt>当前企业标识</dt><dd>{instanceChange.next}</dd></dl></div>}
        {error&&<p ref={errorRef} tabIndex={-1} className="error" role="alert">{error}</p>}
        <button className="primary full" disabled={busy}>{busy?'正在检查连接…':instanceChange?'确认更换并重新登录':'连接并继续'}{!busy&&<Icon name="arrow" size={17}/>}</button>
        {instanceChange&&<button className="full" type="button" disabled={busy} onClick={()=>void run(cancel)}>取消，重新填写地址</button>}
      </form><p className="login-foot">不知道服务地址？请联系企业管理员。</p>
    </div><footer className="login-security"><Icon name="shield" size={14}/>先确认企业服务 · 再验证账号身份</footer>
  </section></main>
}
