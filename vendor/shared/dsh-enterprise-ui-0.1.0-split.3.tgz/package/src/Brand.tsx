/// <reference types="vite/client" />
import logo from './assets/lets-logo.png'

export function Brand({subtitle='企业管理'}:{subtitle?:string}){
  return <div className="brand"><img src={logo} alt="LETS" width={36} height={47}/><div><strong>LETS</strong><span>{subtitle}</span></div></div>
}
export function Icon({name,size=20}:{name:string;size?:number}){
  const paths:Record<string,string>={
    releases:'M4 3h16v12H4V3ZM8 21h8M12 15v6M9 8l3 3 3-3M12 5v6',
    globe:'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM3 12h18M12 3c4 4 4 14 0 18-4-4-4-14 0-18Z',
    analytics:'M3 3v18h18M7 15l4-5 4 3 6-8',
    refresh:'M20 7v5h-5M4 17v-5h5M6 6a8 8 0 0 1 14 6M18 18a8 8 0 0 1-14-6',
    info:'M12 8h.01M12 11v6M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0Z',
    clock:'M12 6v6l4 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0Z',
    employees:'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75',
    departments:'M9 3h6v6H9zM3 15h6v6H3zM15 15h6v6h-6zM12 9v3M6 15v-3h12v3',
    roles:'m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Zm-4 9 3 3 5-6',
    models:'m12 3 9 5v8l-9 5-9-5V8l9-5Zm0 10v8M3 8l9 5 9-5',
    applications:'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',
    resources:'m12 3 9 5-9 5-9-5 9-5ZM3 12l9 5 9-5M3 16l9 5 9-5',
    knowledge:'M3 4h6l3 2 3-2h6v15h-6l-3 2-3-2H3V4Zm9 2v15',
    audit:'M14 3H5v18h14V8l-5-5Zm0 0v5h5M8 12h8M8 16h5',
    account:'M20 21v-2a7 7 0 0 0-14 0v2M13 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8',
    home:'m3 10 9-7 9 7v11h-7v-7h-4v7H3V10Z',
    logout:'M9 3H4v18h5M9 12h12m-5-5 5 5-5 5',
    arrow:'M4 12h16m-6-6 6 6-6 6',
    lock:'M5 10h14v11H5zM8 10V7a4 4 0 0 1 8 0v3M12 14v3',
    eye:'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12ZM15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z',
    shield:'m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Zm-4 9 3 3 5-6',
    plus:'M12 5v14M5 12h14',
    search:'M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0Z',
    edit:'m16 3 5 5-12 12-6 1 1-6L16 3Zm-2 2 5 5',
    pause:'M8 5v14M16 5v14',
    play:'m8 4 12 8-12 8V4Z',
  }
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round"><path d={paths[name]??paths.applications}/></svg>
}
