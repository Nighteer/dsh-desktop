import type { ComponentProps } from 'react';
import { LoginView } from './Login.tsx';
/** Shared visual shell; authentication remains owned by LoginView. */
export declare function AdminLogin(props: ComponentProps<typeof LoginView>): import("react").JSX.Element;
