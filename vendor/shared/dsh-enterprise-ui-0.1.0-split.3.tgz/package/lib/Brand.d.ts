export declare function Brand({ subtitle }: {
    subtitle?: string;
}): import("react").JSX.Element;
export declare function Icon({ name, size }: {
    name: string;
    size?: number;
}): import("react").JSX.Element;
