export interface LoginViewProps {
    login: (username: string, password: string, remember: boolean) => Promise<void>;
    changePassword?: (currentPassword: string, password: string) => Promise<void>;
    mustChangePassword?: boolean;
    allowRemember?: boolean;
    message?: string;
    title?: string;
    serviceOrigin?: string;
    changeService?: () => Promise<void>;
}
/** Shared by the sandboxed Electron login page and the browser development preview. */
export declare function LoginView({ login, changePassword, mustChangePassword, allowRemember, message, title, serviceOrigin, changeService }: LoginViewProps): import("react").JSX.Element;
