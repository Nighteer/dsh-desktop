/** Public knowledge DTOs deliberately exclude upstream credentials. */
export interface KnowledgeConnection {
    id: string;
    name: string;
    baseUrl: string;
    tenantId: string;
    enabled: boolean;
    hasKey: boolean;
}
export interface EnterpriseKnowledgeBase {
    id: string;
    connectionId: string;
    upstreamId: string;
    name: string;
    description: string;
    enabled: boolean;
}
export type AvailableKnowledgeBase = Pick<EnterpriseKnowledgeBase, 'id' | 'name' | 'description'>;
export interface RemoteKnowledgeBase {
    id: string;
    name: string;
    description: string;
}
export interface KnowledgeSource {
    reference: string;
    knowledgeBaseId: string;
    knowledgeBaseName: string;
    documentId: string;
    title: string;
    chunkId: string;
    content: string;
    score: number | null;
}
export interface KnowledgeSearchResult {
    sources: KnowledgeSource[];
}
export interface KnowledgeSelectionView {
    catalog: AvailableKnowledgeBase[];
    selectedIds: string[];
    sources: KnowledgeSource[];
    status: string;
}
/** Evidence belongs to a durable answer, not the next question's selection. */
export interface KnowledgeAnswerSources {
    sources: KnowledgeSource[];
    citedReferences: string[];
    legacy: boolean;
}
/** Only an administrator-controlled service base, never a renderer-supplied proxy target. */
export declare function knowledgeBaseUrl(value: string): string;
