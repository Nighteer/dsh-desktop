export declare const SYSTEM_ADMIN_ROLE_ID = "00000000-0000-4000-8000-000000000001";
export declare const MANAGEMENT_PERMISSIONS: {
    readonly 'analytics.read': "查看运营看板";
    readonly 'employees.manage': "员工管理";
    readonly 'departments.manage': "部门管理";
    readonly 'roles.manage': "角色与权限管理（系统管理员专属）";
    readonly 'models.manage': "企业模型管理";
    readonly 'applications.manage': "企业应用管理";
    readonly 'resources.manage': "技能与 MCP 管理";
    readonly 'knowledge.manage': "企业知识库管理";
    readonly 'audit.read': "查看登录与操作记录";
    readonly 'desktop-releases.manage': "桌面版本发布";
};
export type ManagementPermission = keyof typeof MANAGEMENT_PERMISSIONS;
export interface AssignedRole {
    id: string;
    name: string;
    enabled: boolean;
    builtin: boolean;
}
export interface EnterpriseRole extends AssignedRole {
    description: string;
    permissions: ManagementPermission[];
    memberCount: number;
}
export declare function hasManagementPermission(user: {
    role: string;
    permissions?: readonly ManagementPermission[];
}, permission: ManagementPermission): boolean;
export declare function canManageEnterprise(user: {
    role: string;
    permissions?: readonly ManagementPermission[];
}): boolean;
