export type ResourceKind = 'skill' | 'mcp';
export interface ResourceFile {
    path: string;
    data: string;
}
export type McpConfiguration = {
    transport: 'streamable-http';
    url: string;
    headers: Record<string, string>;
} | {
    transport: 'stdio';
    command: string;
    args: string[];
    env: Record<string, string>;
    cwd: string;
};
export interface ResourceContent {
    kind: ResourceKind;
    files?: ResourceFile[];
    mcp?: McpConfiguration;
}
export interface EnterpriseResource {
    id: string;
    name: string;
    description: string;
    kind: ResourceKind;
    enabled: boolean;
    latestVersion: string | null;
    versions: ResourceVersion[];
}
export interface ResourceVersion {
    id: string;
    version: string;
    notes: string;
    published: boolean;
    enabled: boolean;
    digest: string;
    createdAt: string;
}
export interface AvailableResource extends Omit<EnterpriseResource, 'enabled' | 'versions'> {
    versions: ResourceVersion[];
}
export interface ResourceDelivery {
    resourceId: string;
    versionId: string;
    name: string;
    version: string;
    digest: string;
    content: ResourceContent;
}
export interface LocalResource {
    id: string;
    source: 'enterprise' | 'personal';
    resourceId?: string;
    versionId?: string;
    name: string;
    version: string;
    kind: ResourceKind;
    enabled: boolean;
    status: 'disabled' | 'ready' | 'connecting' | 'failed' | 'revoked';
    message: string;
    tools: string[];
    updatedAt: string;
    /** False for existing local skills discovered through Harness, not owned by this installer. */
    managed?: boolean;
    description?: string;
}
export interface ResourceManagerView {
    catalog: AvailableResource[];
    installed: LocalResource[];
    catalogError: string;
    localError?: string;
}
export declare const RESOURCE_MAX_BYTES: number;
export declare function resourcePath(value: string): string;
export declare function mcpConfiguration(value: unknown): McpConfiguration;
