export type DesktopReleaseChannel = 'stable' | 'beta';
export type DesktopReleasePlatform = 'win32' | 'darwin';
export type DesktopReleaseArch = 'x64' | 'arm64';
export declare const MAX_DESKTOP_INSTALLER_BYTES: number;
export interface DesktopRelease {
    id: string;
    version: string;
    channel: DesktopReleaseChannel;
    platform: DesktopReleasePlatform;
    arch: DesktopReleaseArch;
    notes: string;
    state: 'draft' | 'published' | 'withdrawn';
    filename: string | null;
    size: number | null;
    sha256: string | null;
    createdAt: string;
    publishedAt: string | null;
}
export interface DesktopReleaseCheck {
    instanceId: string;
    release: DesktopRelease | null;
}
export declare function desktopReleaseVersion(value: unknown, channel: unknown): string;
export declare function compareDesktopReleases(a: string, b: string): number;
