import { type ResourceContent, type ResourceFile } from './resources.ts';
export declare function skillMetadata(files: ResourceFile[]): {
    name: string;
    description: string;
    content: string;
    modelInvocable: boolean;
    userInvocable: boolean;
};
export declare function resourceContent(value: unknown, expected?: string): ResourceContent;
export declare function resourceDigest(content: ResourceContent): string;
/** No extraction to disk, no symlinks, no ZIP64, bounded inflation and CRC/central-local agreement. */
export declare function skillZip(bytes: Buffer): ResourceContent;
