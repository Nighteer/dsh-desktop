/** HTTP is permitted only for loopback or an exact origin explicitly allowed by IT. */
export declare function enterpriseOrigin(value: string, allowedHttpOrigins?: readonly string[]): string;
export declare function explicitHttpOrigins(value: string | undefined): string[];
