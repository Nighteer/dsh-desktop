import type { Department, Page } from './index.ts';
export type UsageKind = 'model' | 'knowledge' | 'application' | 'resource_download' | 'resource_install' | 'mcp';
export type UsageStatus = 'running' | 'succeeded' | 'failed' | 'cancelled' | 'interrupted';
export interface UsageTotals {
    events: number;
    users: number;
    modelCalls: number;
    modelSucceeded: number;
    modelFailed: number;
    modelCancelled: number;
    modelInterrupted: number;
    modelRunning: number;
    inputTokens: number | null;
    outputTokens: number | null;
    knownUsageCalls: number;
    averageDurationMs: number | null;
    knowledgeSearches: number;
    knowledgeCompleted: number;
    knowledgeWithResults: number;
    applicationOpens: number;
    downloads: number;
    installed: number;
    installFailed: number;
    mcpCalls: number;
    lastActive: string | null;
}
export interface UsageGroup extends UsageTotals {
    id: string;
    name: string;
    username?: string;
    departmentNames?: string[];
    category?: string;
}
export interface UsageRequest {
    id: string;
    kind: UsageKind;
    status: UsageStatus;
    purpose: 'business' | 'test';
    employeeName: string;
    username: string;
    departmentName: string;
    targetName: string;
    startedAt: string;
    durationMs: number | null;
    inputTokens: number | null;
    outputTokens: number | null;
    resultCount: number | null;
    errorCode: string | null;
}
export interface AnalyticsReport {
    collectedSince: string;
    generatedAt: string;
    timezone: 'Asia/Shanghai';
    missedEvents: number;
    inventory: {
        employees: number;
        enabledEmployees: number;
        departments: number;
        models: number;
        applications: number;
        resources: number;
    };
    summary: UsageTotals;
    trend: ({
        date: string;
    } & UsageTotals)[];
    departments: UsageGroup[];
    employees: Page<UsageGroup>;
    models: UsageGroup[];
    knowledge: UsageGroup[];
    applications: UsageGroup[];
    resources: UsageGroup[];
    legacy: {
        available: boolean;
        modelStarts: number;
        knowledgeResponses: number;
        applicationOpenAuthorizations: number;
        installReceipts: number;
    };
}
export interface AnalyticsOptions {
    departments: Department[];
    models: {
        id: string;
        name: string;
    }[];
}
