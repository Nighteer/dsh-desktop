export interface EnterpriseConnectionProps {
    origin: string;
    message: string;
    instanceChange?: {
        previous: string;
        next: string;
    };
    connect: (origin: string) => Promise<void>;
    confirm: () => Promise<void>;
    cancel: () => Promise<void>;
}
/** Only address selection lives in the renderer; all requests/pins belong to main. */
export declare function EnterpriseConnection({ origin, message, instanceChange, connect, confirm, cancel }: EnterpriseConnectionProps): import("react").JSX.Element;
