export type DeletionKind='employees'|'departments'|'roles'|'model-providers'|'models'|'applications'|'resources'|'knowledge/connections'|'knowledge/bases'
export interface DeletionDependency{key:string;label:string;count:number;clearable:boolean;instruction:string;managePath:string}
export interface DeletionInspection{kind:DeletionKind;id:string;name:string;blockedReason:string|null;dependencies:DeletionDependency[];canDelete:boolean;fingerprint:string}
