/** HTTP is permitted only for loopback or an exact origin explicitly allowed by IT. */
export function enterpriseOrigin(value: string, allowedHttpOrigins: readonly string[] = []): string {
  if (value.length > 2000 || /[\u0000-\u0020\u007f\\]/u.test(value)) throw new Error('企业服务地址格式无效')
  const url = new URL(value)
  if (url.username || url.password || url.search || url.hash || url.pathname !== '/') throw new Error('企业服务地址必须为不含路径、参数或凭证的根地址')
  const loopback = ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname)
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && (loopback || allowedHttpOrigins.includes(url.origin)))) {
    throw new Error('企业服务默认要求 HTTPS；内网 HTTP 需要管理员明确配置允许的源地址')
  }
  return url.origin
}

export function explicitHttpOrigins(value: string | undefined): string[] {
  if (!value?.trim()) return []
  return value.split(',').map(item => {
    const origin = item.trim()
    if (!origin.startsWith('http://') || enterpriseOrigin(origin, [origin]) !== origin) throw new Error('HTTP 兼容配置仅接受完整且精确的 http://主机:端口 源地址')
    return origin
  })
}
