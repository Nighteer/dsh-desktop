export type DesktopReleaseChannel = 'stable' | 'beta'
export type DesktopReleasePlatform = 'win32' | 'darwin'
export type DesktopReleaseArch = 'x64' | 'arm64'
export const MAX_DESKTOP_INSTALLER_BYTES = 1024 * 1024 * 1024
export interface DesktopRelease {
  id:string; version:string; channel:DesktopReleaseChannel; platform:DesktopReleasePlatform; arch:DesktopReleaseArch;
  notes:string; state:'draft'|'published'|'withdrawn'; filename:string|null; size:number|null; sha256:string|null;
  createdAt:string; publishedAt:string|null;
}
export interface DesktopReleaseCheck {instanceId:string; release:DesktopRelease|null}
export function desktopReleaseVersion(value:unknown,channel:unknown):string {
  if(typeof value!=='string'||value.length>64||!/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-beta\.(0|[1-9]\d*))?$/u.test(value)
    ||!['stable','beta'].includes(String(channel))||value.includes('-beta.')!==(channel==='beta'))throw new Error('正式版使用 1.0.0，测试版使用 1.0.0-beta.1 格式')
  return value
}
export function compareDesktopReleases(a:string,b:string):number {
  const parts=(v:string)=>v.split(/\.|-beta\./u).map(BigInt),left=parts(a),right=parts(b)
  for(let i=0;i<3;i++){if(left[i]!>right[i]!)return 1;if(left[i]!<right[i]!)return -1}
  if(left.length!==right.length)return left.length===3?1:-1
  return left[3]===right[3]?0:left[3]!>right[3]!?1:-1
}
