/** Node-only archive/content validation shared by enterprise publishing and Desktop installation. */
import {createHash} from 'node:crypto'
import {inflateRawSync} from 'node:zlib'
import {parseDocument} from 'yaml'
import {RESOURCE_MAX_BYTES, resourcePath, mcpConfiguration, type ResourceContent, type ResourceFile} from './resources.ts'
export function skillMetadata(files: ResourceFile[]): {name: string; description: string; content: string; modelInvocable: boolean; userInvocable: boolean} {
  const file = files.find(file => file.path === 'SKILL.md')
  if (!file) throw new Error('技能包根目录必须包含 SKILL.md')
  const source = new TextDecoder('utf-8', {fatal: true}).decode(Buffer.from(file.data, 'base64')).replace(/^\uFEFF/u, '')
  const match = /^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)([\s\S]*)$/u.exec(source)
  if (!match) throw new Error('SKILL.md 必须包含 YAML 元数据和正文')
  const document = parseDocument(match[1]!, {uniqueKeys: true})
  if (document.errors.length) throw new Error('SKILL.md 元数据格式无效')
  const metadata = document.toJS({maxAliasCount: 0}) as Record<string, unknown>
  if (!metadata || typeof metadata.name !== 'string' || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/u.test(metadata.name) || metadata.name.length > 100 || typeof metadata.description !== 'string' || !metadata.description.trim() || metadata.description.length > 2000 || !match[2]?.trim()) throw new Error('技能需要有效的 name、description 和正文')
  for (const key of ['disable-model-invocation', 'user-invocable']) if (metadata[key] !== undefined && typeof metadata[key] !== 'boolean') throw new Error('技能调用选项必须为布尔值')
  return {name: metadata.name, description: metadata.description, content: match[2], modelInvocable: metadata['disable-model-invocation'] !== true, userInvocable: metadata['user-invocable'] !== false}
}
export function resourceContent(value: unknown, expected?: string): ResourceContent {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('资源内容无效')
  const input = value as ResourceContent
  if (expected && input.kind !== expected) throw new Error('资源类型不匹配')
  if (input.kind === 'mcp') return {kind: 'mcp', mcp: mcpConfiguration(input.mcp)}
  if (input.kind !== 'skill' || !Array.isArray(input.files) || !input.files.length || input.files.length > 300) throw new Error('技能包应包含 1–300 个文件')
  let bytes = 0
  const seen = new Set<string>()
  const files = input.files.map(file => {
    const path = resourcePath(file.path), key = path.toLowerCase()
    if (seen.has(key) || typeof file.data !== 'string' || file.data.length > RESOURCE_MAX_BYTES * 2 || file.data.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/u.test(file.data)) throw new Error('技能包有重复文件或编码错误')
    seen.add(key); bytes += Buffer.byteLength(file.data, 'base64')
    if (bytes > RESOURCE_MAX_BYTES) throw new Error('技能解压后的文件合计不能超过 6 MB')
    return {path, data: Buffer.from(file.data, 'base64').toString('base64')}
  }).sort((a, b) => a.path.localeCompare(b.path, 'en'))
  skillMetadata(files)
  return {kind: 'skill', files}
}
export function resourceDigest(content: ResourceContent): string {return createHash('sha256').update(JSON.stringify(resourceContent(content))).digest('hex')}
function crc32(buffer: Buffer): number {
  let crc = 0xffffffff
  for (const byte of buffer) {crc ^= byte; for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0)}
  return (crc ^ 0xffffffff) >>> 0
}
/** No extraction to disk, no symlinks, no ZIP64, bounded inflation and CRC/central-local agreement. */
export function skillZip(bytes: Buffer): ResourceContent {
  if (bytes.length > 4 * 1024 * 1024 || bytes.length < 22) throw new Error('ZIP 文件必须小于 4 MB 且格式完整')
  let end = -1
  for (let at = bytes.length - 22; at >= Math.max(0, bytes.length - 65557); at--) if (bytes.readUInt32LE(at) === 0x06054b50 && at + 22 + bytes.readUInt16LE(at + 20) === bytes.length) {end = at; break}
  if (end < 0 || bytes.readUInt16LE(end + 4) || bytes.readUInt16LE(end + 6)) throw new Error('不支持此 ZIP 格式')
  const count = bytes.readUInt16LE(end + 10), centralSize = bytes.readUInt32LE(end + 12), centralStart = bytes.readUInt32LE(end + 16)
  if (count > 600 || count !== bytes.readUInt16LE(end + 8) || centralStart + centralSize !== end) throw new Error('ZIP 目录无效或文件过多')
  let offset = centralStart, total = 0
  const files: ResourceFile[] = []
  for (let index = 0; index < count; index++) {
    if (offset + 46 > end || bytes.readUInt32LE(offset) !== 0x02014b50) throw new Error('ZIP 目录损坏')
    const flags = bytes.readUInt16LE(offset + 8), method = bytes.readUInt16LE(offset + 10), crc = bytes.readUInt32LE(offset + 16), packed = bytes.readUInt32LE(offset + 20), unpacked = bytes.readUInt32LE(offset + 24)
    const nameSize = bytes.readUInt16LE(offset + 28), extra = bytes.readUInt16LE(offset + 30), comment = bytes.readUInt16LE(offset + 32), external = bytes.readUInt32LE(offset + 38), local = bytes.readUInt32LE(offset + 42)
    if (offset + 46 + nameSize + extra + comment > end || flags & 1 || ((external >>> 16) & 0xf000) === 0xa000 || unpacked > RESOURCE_MAX_BYTES || ![0, 8].includes(method)) throw new Error('ZIP 包含加密、链接或不支持的文件')
    const nameBytes = bytes.subarray(offset + 46, offset + 46 + nameSize), name = new TextDecoder('utf-8', {fatal: true}).decode(nameBytes)
    offset += 46 + nameSize + extra + comment
    resourcePath(name.endsWith('/') ? name.slice(0, -1) : name)
    if (local + 30 > centralStart || bytes.readUInt32LE(local) !== 0x04034b50 || bytes.readUInt16LE(local + 8) !== method || bytes.readUInt16LE(local + 6) !== flags) throw new Error('ZIP 本地记录无效')
    const localNameSize = bytes.readUInt16LE(local + 26), start = local + 30 + localNameSize + bytes.readUInt16LE(local + 28)
    if (!bytes.subarray(local + 30, local + 30 + localNameSize).equals(nameBytes) || start + packed > centralStart) throw new Error('ZIP 路径或长度不一致')
    total += unpacked
    if (total > RESOURCE_MAX_BYTES) throw new Error('ZIP 解压总量超过 6 MB')
    const data = method === 0 ? bytes.subarray(start, start + packed) : inflateRawSync(bytes.subarray(start, start + packed), {maxOutputLength: Math.max(1, RESOURCE_MAX_BYTES - total + unpacked)})
    if (data.length !== unpacked || crc32(data) !== crc) throw new Error('ZIP 文件校验失败')
    if (!name.endsWith('/')) files.push({path: name, data: data.toString('base64')})
  }
  if (offset !== end) throw new Error('ZIP 目录长度不一致')
  if (!files.some(file => file.path === 'SKILL.md')) {
    const prefix = files[0]?.path.split('/')[0] + '/'
    if (files.every(file => file.path.startsWith(prefix))) for (const file of files) file.path = file.path.slice(prefix.length)
  }
  return resourceContent({kind: 'skill', files})
}
