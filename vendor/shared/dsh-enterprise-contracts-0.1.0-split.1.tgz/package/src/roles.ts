export const SYSTEM_ADMIN_ROLE_ID='00000000-0000-4000-8000-000000000001'
export const MANAGEMENT_PERMISSIONS={
  'analytics.read':'查看运营看板',
  'employees.manage':'员工管理',
  'departments.manage':'部门管理',
  'roles.manage':'角色与权限管理（系统管理员专属）',
  'models.manage':'企业模型管理',
  'applications.manage':'企业应用管理',
  'resources.manage':'技能与 MCP 管理',
  'knowledge.manage':'企业知识库管理',
  'audit.read':'查看登录与操作记录',
  'desktop-releases.manage':'桌面版本发布',
} as const
export type ManagementPermission=keyof typeof MANAGEMENT_PERMISSIONS
export interface AssignedRole{id:string;name:string;enabled:boolean;builtin:boolean}
export interface EnterpriseRole extends AssignedRole{description:string;permissions:ManagementPermission[];memberCount:number}
export function hasManagementPermission(user:{role:string;permissions?:readonly ManagementPermission[]},permission:ManagementPermission):boolean{
  return user.role==='admin'||user.permissions?.includes(permission)===true
}
export function canManageEnterprise(user:{role:string;permissions?:readonly ManagementPermission[]}):boolean{
  return user.role==='admin'||Boolean(user.permissions?.some(permission=>Object.hasOwn(MANAGEMENT_PERMISSIONS,permission)))
}
