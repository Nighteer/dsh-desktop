export type ResourceKind = 'skill' | 'mcp'
export interface ResourceFile {path: string; data: string}
export type McpConfiguration =
  | {transport: 'streamable-http'; url: string; headers: Record<string, string>}
  | {transport: 'stdio'; command: string; args: string[]; env: Record<string, string>; cwd: string}
export interface ResourceContent {kind: ResourceKind; files?: ResourceFile[]; mcp?: McpConfiguration}
export interface EnterpriseResource {
  id: string; name: string; description: string; kind: ResourceKind; enabled: boolean;
  latestVersion: string | null; versions: ResourceVersion[];
}
export interface ResourceVersion {id: string; version: string; notes: string; published: boolean; enabled: boolean; digest: string; createdAt: string}
export interface AvailableResource extends Omit<EnterpriseResource, 'enabled' | 'versions'> {versions: ResourceVersion[]}
export interface ResourceDelivery {resourceId: string; versionId: string; name: string; version: string; digest: string; content: ResourceContent}
export interface LocalResource {
  id: string; source: 'enterprise' | 'personal'; resourceId?: string; versionId?: string;
  name: string; version: string; kind: ResourceKind; enabled: boolean;
  status: 'disabled' | 'ready' | 'connecting' | 'failed' | 'revoked'; message: string;
  tools: string[]; updatedAt: string;
  /** False for existing local skills discovered through Harness, not owned by this installer. */
  managed?: boolean; description?: string;
}
export interface ResourceManagerView {catalog: AvailableResource[]; installed: LocalResource[]; catalogError: string; localError?: string}
export const RESOURCE_MAX_BYTES = 6 * 1024 * 1024
export function resourcePath(value: string): string {
  if (!value || value.length > 220 || value.includes('\\') || value.startsWith('/') || value.endsWith('/')) throw new Error('技能文件路径无效')
  for (const part of value.split('/')) if (!part || part === '.' || part === '..' || /[\u0000-\u001f<>:"|?*]/u.test(part) || /[. ]$/u.test(part) || /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/iu.test(part)) throw new Error('技能文件路径不安全')
  return value
}
export function mcpConfiguration(value: unknown): McpConfiguration {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('MCP 配置必须是对象')
  let item = value as Record<string, unknown>
  if (item.mcpServers && typeof item.mcpServers === 'object' && !Array.isArray(item.mcpServers)) {
    const servers = Object.values(item.mcpServers)
    if (servers.length !== 1) throw new Error('每次只导入一个 MCP 服务')
    return mcpConfiguration(servers[0])
  }
  const declaredType = item.type === 'http' ? 'streamable-http' : item.type
  if (declaredType !== undefined && item.transport !== undefined && declaredType !== item.transport) throw new Error('MCP 的 type 与 transport 配置不一致')
  item = {...item, transport: item.transport ?? declaredType}
  if (item.transport !== undefined && item.transport !== 'stdio' && item.transport !== 'streamable-http') throw new Error('首期仅支持 stdio 或 Streamable HTTP，不支持旧版 SSE')
  if (item.transport === 'stdio' && item.url !== undefined) throw new Error('stdio 配置不能同时包含远程地址')
  const text = (v: unknown, max = 2000) => {if (typeof v !== 'string' || v.length > max || /[\u0000\r\n]/u.test(v)) throw new Error('MCP 参数无效'); return v}
  const dictionary = (v: unknown): Record<string, string> => {
    if (v === undefined) return {}
    if (!v || typeof v !== 'object' || Array.isArray(v) || Object.keys(v).length > 32) throw new Error('MCP 配置项无效')
    return Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b,'en')).map(([key, val]) => {
      if (!/^[A-Za-z][A-Za-z0-9_-]{0,79}$/u.test(key) || /^(DSH_|NODE_OPTIONS$|ELECTRON_|LD_PRELOAD$|DYLD_)/iu.test(key)) throw new Error('不允许覆盖应用运行环境')
      return [key, text(val, 4000)]
    }))
  }
  if (item.transport === 'streamable-http' || item.url !== undefined) {
    const url = new URL(text(item.url))
    if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.hash || url.search) throw new Error('MCP 地址须为不含凭证、参数或片段的 HTTP(S) 地址')
    const headers = dictionary(item.headers)
    if (Object.keys(headers).some(key => /^(host|origin|cookie|connection|content-length|transfer-encoding|mcp-session-id|mcp-protocol-version)$/iu.test(key))) throw new Error('不允许覆盖 MCP 协议标头')
    return {transport: 'streamable-http', url: url.href, headers}
  }
  if (item.transport !== undefined && item.transport !== 'stdio') throw new Error('首期仅支持 stdio 或 Streamable HTTP，不支持旧版 SSE')
  const command = text(item.command)
  if (/^(?:.*[/\\])?(npx|npm|pnpm|yarn|uvx|pipx|pip|bunx)(?:\.exe|\.cmd)?$/iu.test(command)) throw new Error('首期只连接本机已有 MCP 程序，不通过包管理器自动下载运行')
  if (!command || /^(?:.*[/\\])?(cmd|powershell|pwsh|bash|sh)(?:\.exe)?$/iu.test(command)) throw new Error('请选择 MCP 程序本身，不允许通过 Shell 执行命令')
  if (item.args !== undefined && (!Array.isArray(item.args) || item.args.length > 64)) throw new Error('MCP 参数过多')
  return {transport: 'stdio', command, args: ((item.args ?? []) as unknown[]).map(v => text(v)), env: dictionary(item.env), cwd: text(item.cwd ?? '')}
}
