/** Public knowledge DTOs deliberately exclude upstream credentials. */
export interface KnowledgeConnection {id:string;name:string;baseUrl:string;tenantId:string;enabled:boolean;hasKey:boolean}
export interface EnterpriseKnowledgeBase {id:string;connectionId:string;upstreamId:string;name:string;description:string;enabled:boolean}
export type AvailableKnowledgeBase = Pick<EnterpriseKnowledgeBase,'id'|'name'|'description'>
export interface RemoteKnowledgeBase {id:string;name:string;description:string}
export interface KnowledgeSource {reference:string;knowledgeBaseId:string;knowledgeBaseName:string;documentId:string;title:string;chunkId:string;content:string;score:number|null}
export interface KnowledgeSearchResult {sources:KnowledgeSource[]}
export interface KnowledgeSelectionView {catalog:AvailableKnowledgeBase[];selectedIds:string[];sources:KnowledgeSource[];status:string}
/** Evidence belongs to a durable answer, not the next question's selection. */
export interface KnowledgeAnswerSources {sources:KnowledgeSource[];citedReferences:string[];legacy:boolean}

/** Only an administrator-controlled service base, never a renderer-supplied proxy target. */
export function knowledgeBaseUrl(value:string):string {
  if(value.trim()!==value||/[\s\\\u0000-\u001f]/u.test(value))throw new Error('知识库地址无效')
  const url=new URL(value)
  if(!['https:','http:'].includes(url.protocol)||url.username||url.password||url.search||url.hash)throw new Error('知识库地址须为 HTTP(S)，不能包含凭证、参数或片段')
  if(['169.254.169.254','metadata.google.internal','metadata'].includes(url.hostname)||url.hostname.startsWith('169.254.')||url.hostname.startsWith('[fe80:')||['4310','5180'].includes(url.port))throw new Error('不允许连接元数据地址或企业服务自身端口')
  if(url.pathname!=='/'&&url.pathname!=='/api/v1'&&url.pathname!=='/api/v1/')throw new Error('请填写服务根地址，不包含登录页或接口路径')
  return url.origin
}
