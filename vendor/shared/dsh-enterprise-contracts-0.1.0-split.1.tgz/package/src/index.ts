import type {AssignedRole,ManagementPermission} from './roles.ts'
export * from './roles.ts'
export * from './deletion.ts'
export * from './analytics.ts'
export * from './desktop-releases.ts'
export type Role = 'admin' | 'employee'
export interface Employee {
  id: string; username: string; name: string; departmentId: string; departmentName: string;
  role: Role; enabled: boolean; mustChangePassword: boolean; createdAt: string;
  roles?:AssignedRole[]; permissions?:ManagementPermission[];
}
export interface Department { id: string; name: string; parentId: string | null; enabled: boolean }
export interface Identity { instanceId: string; user: Employee }
export interface LoginInput { username: string; password: string; channel: 'browser' | 'desktop'; remember?: boolean }
export interface DesktopSession extends Identity { accessToken: string; refreshToken: string; expiresAt: string }
export interface EmployeeInput { username: string; name: string; departmentId: string; role: Role; enabled: boolean }
export interface Page<T> { items: T[]; total: number; page: number; pageSize: number }
export interface AuditEvent { id: string; action: string; actor: string | null; target: string | null; ip: string; createdAt: string; actorUsername?:string|null;targetName?:string|null }
export type ErrorCode = 'INVALID_INPUT' | 'UNAUTHENTICATED' | 'FORBIDDEN' | 'PASSWORD_CHANGE_REQUIRED' | 'CONFLICT' | 'RATE_LIMITED' | 'UNAVAILABLE'
export interface ApiError { error: { code: ErrorCode; message: string } }
export const API_PREFIX = '/api/v1'
/** Public, credential-free handshake used before the desktop submits a password. */
export interface EnterpriseDesktopInfo { product: 'lets-enterprise'; desktopApiVersion: 1; instanceId: string }
export * from './resources.ts'
export * from './knowledge.ts'

/** No upstream key or encrypted secret is ever part of a public DTO. */
export interface ModelProvider { id: string; name: string; baseUrl: string; enabled: boolean; hasKey: boolean }
export type ThinkingMode = 'provider' | 'enabled' | 'disabled'
export type ThinkingFormat = 'deepseek' | 'chat-template'
export interface EnterpriseModel {
  id: string; providerId: string; name: string; upstreamModel: string; enabled: boolean;
  contextWindow: number | null; maxTokens: number | null;
  supportsTools: boolean; supportsImages: boolean; protocol: 'chat-completions'; thinkingMode: ThinkingMode; thinkingFormat: ThinkingFormat;
  detectedContextWindow: number | null; detectedMaxTokens: number | null; metadataReadAt: string | null;
}
export interface ModelGrant { subjectType: 'employee' | 'department' | 'role'; subjectId: string }
export type ApplicationIcon = 'globe' | 'contract' | 'knowledge' | 'tool'
export interface EnterpriseApplication {
  id: string; name: string; description: string; url: string; icon: ApplicationIcon; enabled: boolean; sortOrder: number;
  allowedOrigins: string[];
}
export type ApplicationGrant = ModelGrant
export type AvailableApplication = Omit<EnterpriseApplication, 'url' | 'enabled' | 'allowedOrigins'>
export interface ApplicationLaunch { url: string; allowedOrigins: string[]; revision: number; openMode: 'embedded' }

export function enterpriseApplicationOrigin(value: string): string {
  const url = new URL(enterpriseApplicationUrl(value))
  if (url.pathname !== '/' || url.search || url.hash) throw new Error('允许站点只能填写源地址（协议、域名及端口），不能包含路径或参数')
  return url.origin
}

/** Web entry points are ordinary HTTP(S) URLs, never executable protocols or embedded credentials. */
export function enterpriseApplicationUrl(value: string): string {
  if (value.length > 2000 || /[\u0000-\u0020\u007f]/u.test(value)) throw new Error('应用网址无效')
  const url = new URL(value)
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || !url.hostname) throw new Error('应用网址仅支持不含内嵌凭证的 HTTP / HTTPS 地址')
  return url.href
}
export interface AvailableModel {
  id: string; name: string; contextWindow: number | null; maxTokens: number | null;
  supportsTools: boolean; supportsImages: boolean;
  contextSource: 'manual' | 'provider' | 'unknown';
}
export interface DiscoveredEnterpriseModel {
  id: string; name: string; contextWindow: number | null; maxTokens: number | null;
  supportsTools: boolean | null; supportsImages: boolean | null;
}

/** Remote plain HTTP requires an explicit administrator acknowledgment when saving a new URL. */
export function isRemoteHttpModelUrl(value: string): boolean {
  try {
    const url = new URL(value)
    return url.protocol === 'http:' && !['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname)
  } catch { return false }
}
export { enterpriseOrigin, explicitHttpOrigins } from './enterprise-origin.ts'
